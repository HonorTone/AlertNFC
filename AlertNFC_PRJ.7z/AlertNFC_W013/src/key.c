/*
 * key.c
 *
 *  Created on: 2016-8-23
 *      Author: Administrator
 */
void scanKey()
{
    int a=0;
}
